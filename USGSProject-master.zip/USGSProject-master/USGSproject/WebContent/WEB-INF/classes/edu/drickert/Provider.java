package edu.drickert;

public interface Provider {
	String username="postgres";
	String pwd = "password";
	String connURL="jdbc:postgresql://localhost:5432/tabledb";
	

}